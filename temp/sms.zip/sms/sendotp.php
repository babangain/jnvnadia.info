<?php
    include('way2sms-api.php');
   sendWay2SMS ( '9609775499' , 'A9736C' , '7908179075' , 'Hello World');
  echo "Sms Sent";
?>