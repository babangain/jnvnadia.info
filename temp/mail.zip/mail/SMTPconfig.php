<?php
//Server Address
$SmtpServer="mail.gmail.com";
$SmtpPort="465"; //default
$SmtpUser="nadiajnv@gmail.com";
$SmtpPass="baban0000";
?>